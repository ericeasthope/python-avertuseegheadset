from . import AvertusEEGHeadset

__version__ = '1.0.2'

__all__ = [
  'AvertusEEGHeadset'
]
