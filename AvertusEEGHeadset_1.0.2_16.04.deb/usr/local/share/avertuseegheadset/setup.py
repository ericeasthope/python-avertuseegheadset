#!/usr/bin/env python

from setuptools import setup, find_packages

setup(
    name="avertuseegheadset",
    version="1.0.2",
    packages=find_packages(),
    # Project uses reStructuredText, so ensure that the docutils get
    # installed or upgraded on the target machine
    package_data={
        # Copy Library
        '': ['AvertusEEGHeadset.so'],
    },
    zip_safe=False,
    # metadata for upload to PyPI
    author="Gaitech",
    author_email="me@example.com",
    description="Python moudle to connect with avertus eeg headset",
    license="(c) Gaitech Systems 2018, use as permissible by Gaitech",
    keywords="gaitech avertus bci",
    url="www.gaitech.hk",
    long_description='Python module to connect with Avertus H10C EEG Headset. For use in Gaitech BCI Applications',
    platforms=['x86_64'],
    include_package_data=True,
    install_requires=[]
    # could also include long_description, download_url, classifiers, etc.
)
